namespace Platformer.Core
{
    public class IntGreatOrEqualZeroSpecification : ISpecification<int>
    {
        public bool IsSatisfiedBy(int value)
        {
            return value >= 0;
        }
    }
}
