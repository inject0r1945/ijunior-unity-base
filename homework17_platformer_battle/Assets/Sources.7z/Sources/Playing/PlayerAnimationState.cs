namespace Platformer.Playing
{
    public enum PlayerAnimationState
    {
        Idle,
        Run,
        Jump
    }
}
