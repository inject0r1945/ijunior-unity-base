using Platformer.Attributes;
using Platformer.Capabilities;
using Platformer.Control;
using Platformer.Core;
using UnityEngine;

namespace Platformer.Playing
{
    [RequireComponent(typeof(Animator))]
    [RequireComponent(typeof(SpriteRenderer))]
    [RequireComponent(typeof(ControlSettings))]
    [RequireComponent(typeof(CollisionsDataRetriever))]
    [RequireComponent(typeof(Rigidbody2D))]
    public class AnimationController : MonoBehaviour
    {
        private const float ZeroSpeedThreshold = 0.02f;
        private const int RightWallNormal = 1;
        private readonly string _animatorStateName = "State";
        private readonly string _animatorAirSpeedYName = "AirSpeedY";
        private readonly string _animatorDoubleJumpTriggerName = "DoubleJump";
        private readonly string _animatorHitTriggerName = "Hit";
        private readonly string _animatorDieTriggerName = "Die";
        private readonly string _animatorBoolWallName = "OnWall";
        private int _animatorStateHash;
        private int _animatorAirSpeedYHash;
        private int _animatorDoubleJumpTriggerHash;
        private int _animatorHitTriggerHash;
        private int _animatorDieTriggerHash;
        private int _animatorBoolWallHash;
        private Animator _animator;
        private SpriteRenderer _spriteRenderer;
        private ControlSettings _controller;
        private Jumper _jumper;
        private CollisionsDataRetriever _collisionsDataRetriever;
        private Rigidbody2D _rigidbody;
        private Health _health;
        private bool _isDiedPlayer;

        private enum AnimationState
        {
            Idle,
            Run,
            Jump
        }

        private void Awake()
        {
            _animator = GetComponent<Animator>();
            _spriteRenderer = GetComponent<SpriteRenderer>();
            _controller = GetComponent<ControlSettings>();
            _jumper = GetComponent<Jumper>();
            _collisionsDataRetriever = GetComponent<CollisionsDataRetriever>();
            _rigidbody = GetComponent<Rigidbody2D>();
            _health = GetComponent<Health>();

            _animatorStateHash = Animator.StringToHash(_animatorStateName);
            _animatorAirSpeedYHash = Animator.StringToHash(_animatorAirSpeedYName);
            _animatorDoubleJumpTriggerHash = Animator.StringToHash(_animatorDoubleJumpTriggerName);
            _animatorHitTriggerHash = Animator.StringToHash(_animatorHitTriggerName);
            _animatorDieTriggerHash = Animator.StringToHash(_animatorDieTriggerName);
            _animatorBoolWallHash = Animator.StringToHash(_animatorBoolWallName);
        }

        private void OnEnable()
        {
            if (_jumper != null)
                _jumper.Jumped += OnJumped;

            if (_health != null)
            {
                _health.Damaged.AddListener(OnDamaged);
                _health.Died += OnDied;
            }
        }

        private void OnDisable()
        {
            if (_jumper != null)
                _jumper.Jumped -= OnJumped;
            
            if (_health != null)
            {
                _health.Damaged.RemoveListener(OnDamaged);
                _health.Died -= OnDied;
            }
        }

        private void Update()
        {
            if (_isDiedPlayer)
                return;

            _animator.SetFloat(_animatorAirSpeedYHash, _rigidbody.velocity.y);

            SwitchSpriteDirection();

            CalculateIddleAnimation();
            CalculateRunAnimation();
            CalculateJumpWallAnimation();
            CalculateJumpAnimation();
        }

        private void OnJumped()
        {
            _animator.SetInteger(_animatorStateName, (int)AnimationState.Jump);

            if (_jumper.IsJumped && !_collisionsDataRetriever.OnWall)
                _animator.SetTrigger(_animatorDoubleJumpTriggerHash);
        }

        private void OnDamaged()
        {
            _animator.SetTrigger(_animatorHitTriggerHash);
        }

        private void OnDied()
        {
            _animator.SetTrigger(_animatorDieTriggerHash);
        }

        private void SwitchSpriteDirection()
        {
            float movementDirection = _controller.InputController.RetrieveMovementInput();
            bool isHorizontalMovement = Mathf.Abs(_rigidbody.velocity.x) > ZeroSpeedThreshold;

            if (_collisionsDataRetriever.OnWall && !_collisionsDataRetriever.OnGround)
                _spriteRenderer.flipX = Mathf.Round(_collisionsDataRetriever.ContactNormal.x) == RightWallNormal;

            else if (movementDirection != 0)
                _spriteRenderer.flipX = movementDirection < 0f;

            else if (isHorizontalMovement)
                _spriteRenderer.flipX = _rigidbody.velocity.x < -ZeroSpeedThreshold;
        }

        private void CalculateIddleAnimation()
        {
            if (_collisionsDataRetriever.OnGround && Mathf.Abs(_rigidbody.velocity.y) <= ZeroSpeedThreshold
                && Mathf.Abs(_rigidbody.velocity.x) <= ZeroSpeedThreshold)
                _animator.SetInteger(_animatorStateHash, (int)AnimationState.Idle);
        }

        private void CalculateRunAnimation()
        {
            if (_collisionsDataRetriever.OnGround && Mathf.Abs(_rigidbody.velocity.x) > ZeroSpeedThreshold
                && !_collisionsDataRetriever.OnWall && _rigidbody.velocity.y < ZeroSpeedThreshold)
            {
                _animator.SetInteger(_animatorStateHash, (int)AnimationState.Run);
            }
        }

        private void CalculateJumpWallAnimation()
        {
            bool isEnableWallAnimation = _collisionsDataRetriever.OnWall && !_collisionsDataRetriever.OnGround;
            _animator.SetBool(_animatorBoolWallHash, isEnableWallAnimation);
        }

        private void CalculateJumpAnimation()
        {
            if (Mathf.Abs(_rigidbody.velocity.y) > ZeroSpeedThreshold)
                _animator.SetInteger(_animatorStateName, (int)AnimationState.Jump);
        }
    }
}
