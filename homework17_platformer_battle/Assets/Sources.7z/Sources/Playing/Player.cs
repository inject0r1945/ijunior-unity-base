using UnityEngine;

namespace Platformer.Playing
{
    [RequireComponent(typeof(Rigidbody2D))]
    public class Player : MonoBehaviour
    {
        private Rigidbody2D _rigidbody;

        public void Initialize()
        {
            _rigidbody = GetComponent<Rigidbody2D>();
        }

        private void Awake()
        {
            Initialize();
        }

        private void FixedUpdate()
        {
            _rigidbody.WakeUp();
        }
    }
}
