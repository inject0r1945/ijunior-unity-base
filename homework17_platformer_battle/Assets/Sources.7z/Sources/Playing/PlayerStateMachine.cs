using FiniteStateMachine;
using FiniteStateMachine.States;
using Platformer.Capabilities;
using UnityEngine;

namespace Platformer.Playing.PlayerStateMachineStates
{
    [RequireComponent(typeof(Animator))]
    [RequireComponent(typeof(Movement))]
    [RequireComponent(typeof(Jumper))]
    [RequireComponent(typeof(Rigidbody2D))]
    public class PlayerStateMachine : MonoBehaviour
    {
        private StateMachine _stateMachine;
        private Rigidbody2D _rigidbody;
        private IState _idleState;
        private IState _runState;
        private IState _jumpState;
        private IState _doubleJumpState;
        private IState _fallState;
        private IState _damageState;
        private IState _dieState;
        private Movement _movement;
        private Jumper _jumper;
        private Animator _animator;

        public void Initialize()
        {
            _movement = GetComponent<Movement>();
            _jumper = GetComponent<Jumper>();
            _stateMachine = new StateMachine();
            _rigidbody = GetComponent<Rigidbody2D>();
            _animator = GetComponent<Animator>();

            _idleState = new IdleState(_animator);
            _runState = new RunState(_animator);
            _jumpState = new JumpState(_animator);
            _doubleJumpState = new DoubleJumpState(_animator);
            _fallState = new FallState(_animator);
            _damageState = new DamageState(_animator);
            _dieState = new DieState(_animator);

            SetupStateMachine();
        }

        private void Awake()
        {
            Initialize();
        }

        private void Update()
        {
            _stateMachine.Update();
        }

        private void FixedUpdate()
        {
            _stateMachine.FixedUpdate();
        }

        private void SetupStateMachine()
        {
            _stateMachine.AddInterruptingTransition(_runState, 
                new FunctionPredicate(() => _movement.IsMoved && _jumper.IsJumped == false));
            
            _stateMachine.AddInterruptingTransition(_idleState,
                new FunctionPredicate(() => _movement.IsMoved == false && _jumper.IsJumped == false && _rigidbody.velocity.y == 0));

            _stateMachine.AddInterruptingTransition(_doubleJumpState,
                new FunctionPredicate(() => _jumper.IsDoubleJumped && _rigidbody.velocity.y > 0));

            _stateMachine.AddInterruptingTransition(_jumpState,
                new FunctionPredicate(() => _jumper.IsJumped && _rigidbody.velocity.y > 0));

            _stateMachine.AddInterruptingTransition(_fallState,
                new FunctionPredicate(() => _rigidbody.velocity.y < 0));

            _stateMachine.TrySetState(_idleState);
        }
    }
}