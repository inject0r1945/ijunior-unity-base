using UnityEngine;

namespace Platformer.Playing.PlayerStateMachineStates
{
    public class JumpState : BasePlayerState
    {
        private readonly string _jumpAnimationName = "jump";
        private readonly int _jumpAnimationHash;

        public JumpState(Animator animator) : base(animator)
        {
            _jumpAnimationHash = Animator.StringToHash(_jumpAnimationName);
        }

        public override void OnEnter()
        {
            PlayAnimation(_jumpAnimationHash);
            Debug.Log($"Enter {nameof(JumpState)}");
        }
    }
}
