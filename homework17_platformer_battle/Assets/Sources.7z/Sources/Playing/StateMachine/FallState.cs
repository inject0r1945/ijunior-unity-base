using UnityEngine;

namespace Platformer.Playing.PlayerStateMachineStates
{
    public class FallState : BasePlayerState
    {
        private readonly string _fallAnimationName = "fall";
        private readonly int _fallAnimationHash;

        public FallState(Animator animator) : base(animator)
        {
            _fallAnimationHash = Animator.StringToHash(_fallAnimationName);
        }

        public override void OnEnter()
        {
            PlayAnimation(_fallAnimationHash);
            Debug.Log($"Enter {nameof(FallState)}");
        }
    }
}
