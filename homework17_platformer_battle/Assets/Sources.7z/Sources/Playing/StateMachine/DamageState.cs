using Platformer.Capabilities;
using UnityEngine;

namespace Platformer.Playing.PlayerStateMachineStates
{
    public class DamageState : BasePlayerState
    {
        private readonly string _damageTrigger = "Hit";
        private readonly int _damageTriggerHash;

        public DamageState(Animator animator) : base(animator)
        {
            _damageTriggerHash = Animator.StringToHash(_damageTrigger);
        }

        public override void OnEnter()
        {
            SetAnimatorTrigger(_damageTriggerHash);
        }
    }
}
