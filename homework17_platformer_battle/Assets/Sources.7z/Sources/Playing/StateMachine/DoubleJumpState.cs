using UnityEngine;

namespace Platformer.Playing.PlayerStateMachineStates
{
    public class DoubleJumpState : BasePlayerState
    {
        private readonly string _startDoubleJumpTrigger = "StartDoubleJump";
        private readonly int _startDoubleJumpTriggerHash;
        private readonly string _endDoubleJumpTrigger = "EndDoubleJump";
        private readonly int _endDoubleJumpTriggerHash;

        public DoubleJumpState(Animator animator) : base(animator)
        {
            _startDoubleJumpTriggerHash = Animator.StringToHash(_startDoubleJumpTrigger);
            _endDoubleJumpTriggerHash = Animator.StringToHash(_endDoubleJumpTrigger);
        }

        public override void OnEnter()
        {
            SetAnimatorTrigger(_startDoubleJumpTriggerHash);
            Debug.Log($"Enter {nameof(DoubleJumpState)}");
        }

        public override void OnExit()
        {
            SetAnimatorTrigger(_endDoubleJumpTriggerHash);
        }
    }
}
