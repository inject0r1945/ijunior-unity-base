using Platformer.Capabilities;
using UnityEngine;

namespace Platformer.Playing.PlayerStateMachineStates
{
    public class DieState : BasePlayerState
    {
        private readonly string _dieTrigger = "Die";
        private readonly int _dieTriggerHash;

        public DieState(Animator animator) : base(animator)
        {
            _dieTriggerHash = Animator.StringToHash(_dieTrigger);
        }

        public override void OnEnter()
        {
            SetAnimatorTrigger(_dieTriggerHash);
        }
    }
}
