using UnityEngine;

namespace Platformer.Playing.PlayerStateMachineStates
{
    public class IdleState : BasePlayerState
    {
        private readonly string _idleAnimationName = "idle";
        private readonly int _idleAnimationHash;

        public IdleState(Animator animator) : base(animator)
        {
            _idleAnimationHash = Animator.StringToHash(_idleAnimationName);
        }

        public override void OnEnter()
        {
            PlayAnimation(_idleAnimationHash);
            Debug.Log($"Enter {nameof(IdleState)}");
        }
    }
}