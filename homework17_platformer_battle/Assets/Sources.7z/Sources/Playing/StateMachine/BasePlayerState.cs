using FiniteStateMachine.States;
using UnityEngine;

namespace Platformer.Playing.PlayerStateMachineStates
{
    public class BasePlayerState : BaseState
    {
        private readonly Animator _animator;

        public BasePlayerState(Animator animator)
        {
            _animator = animator;
        }

        protected void PlayAnimation(int animationHash)
        {
            _animator.Play(animationHash);
        }

        protected void SetAnimatorTrigger(int triggerHash)
        {
            _animator.SetTrigger(triggerHash);
        }
    }
}
