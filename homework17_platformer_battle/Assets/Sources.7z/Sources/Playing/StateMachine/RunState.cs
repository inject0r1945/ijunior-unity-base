using UnityEngine;

namespace Platformer.Playing.PlayerStateMachineStates
{
    public class RunState : BasePlayerState
    {
        private readonly string _runAnimationName = "run";
        private readonly int _runAnimationHash;

        public RunState(Animator animator) : base(animator)
        {
            _runAnimationHash = Animator.StringToHash(_runAnimationName);
        }

        public override void OnEnter()
        {
            PlayAnimation(_runAnimationHash);
            Debug.Log($"Enter {nameof(RunState)}");
        }
    }
}