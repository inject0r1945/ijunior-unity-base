using UnityEngine;

namespace Platformer.Environment
{
    public class Platform : MonoBehaviour
    {
    }
}
