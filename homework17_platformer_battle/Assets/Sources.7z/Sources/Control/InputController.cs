using UnityEngine;

namespace Platformer.Control
{
    public abstract class InputController : ScriptableObject
    {
        public abstract float RetrieveMovementInput();
        public abstract bool RetrieveJumpInput();
        public abstract bool RetrieveJumpHoldInput();
    }
}
