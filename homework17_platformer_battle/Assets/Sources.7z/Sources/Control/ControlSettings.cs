using Sirenix.OdinInspector;
using UnityEngine;

namespace Platformer.Control
{
    public class ControlSettings : MonoBehaviour
    {
        [SerializeField, Required] private InputController _inputController;

        public InputController InputController => _inputController;
    }
}