using Platformer.Playing;

namespace Platformer.Enemies.StateMachines
{
    public class ChaseState : EnemyBaseState
    {
        public ChaseState(Player player) : base(player)
        {
        }
    }
}
