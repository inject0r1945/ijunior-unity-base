namespace Platformer.Attributes
{
    public interface IDamageable
    {
        public void TakeDamage(int damage);
    }
}
