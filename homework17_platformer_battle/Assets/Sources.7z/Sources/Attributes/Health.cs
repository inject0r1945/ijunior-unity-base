using Platformer.Core;
using Sirenix.OdinInspector;
using System;
using UnityEngine;
using UnityEngine.Events;

namespace Platformer.Attributes
{
    public class Health : MonoBehaviour, IDamageable
    {
        [SerializeField, Required, MinValue(0)] private int _maxValue = 3;

        private const int MinValue = 0;
        private int _currentValue;
        private bool _isEnableDamage = true;
        private ISpecification<int> _damageSpecification;
        private ISpecification<int> _healthSpecification;

        public UnityEvent Damaged;

        public event Action<int> Changed;

        public event Action Died;

        public int CurrentValue
        {
            get => _currentValue;

            private set
            {
                _currentValue = value;

                if (!_healthSpecification.IsSatisfiedBy(_currentValue))
                    _currentValue = MinValue;
            }
        }

        public bool IsDied => CurrentValue == 0;

        private void Awake()
        {
            _damageSpecification = new IntGreatOrEqualZeroSpecification();
            _healthSpecification = new IntGreatOrEqualZeroSpecification();
            CurrentValue = _maxValue;
        }

        public void TakeDamage(int damage)
        {
            if (!_isEnableDamage)
                return;

            if (!_damageSpecification.IsSatisfiedBy(damage))
                return;

            CurrentValue -= damage;

            Changed?.Invoke(CurrentValue);
            Damaged?.Invoke();

            if (CurrentValue == 0)
                Died?.Invoke();
        }

        public void DisableDamage()
        {
            _isEnableDamage = true;
        }

        public void EnableDamage()
        {
            _isEnableDamage = false;
        }
    }
}
