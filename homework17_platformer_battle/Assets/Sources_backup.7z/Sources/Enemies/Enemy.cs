using FiniteStateMachine;
using FiniteStateMachine.States;
using Platformer.Attributes;
using Platformer.Enemies.StateMachines;
using Platformer.Game;
using UnityEngine;

namespace Platformer.Enemies
{
    [RequireComponent(typeof(Health))]
    public class Enemy : MonoBehaviour
    {
        private StateMachine _stateMachine = new();

        public void Initialize(Player player)
        {
            IState idleState = new IdleState(player);
            IState patrolState = new PatrolState(player);
            IState chaseState = new ChaseState(player);
            IState attackState = new AttackState(player);

            _stateMachine.AddTransition(idleState, chaseState, new FunctionPredicate(() => true));

            //_stateMachine.AddInterruptingTransition(_stateMachine)
        }

        private void Update()
        {
            _stateMachine.Update();
        }

        private void FixedUpdate()
        {
            _stateMachine.FixedUpdate();
        }
    }
}
