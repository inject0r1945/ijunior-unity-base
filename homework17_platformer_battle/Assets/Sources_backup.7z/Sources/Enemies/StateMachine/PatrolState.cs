using Platformer.Game;

namespace Platformer.Enemies.StateMachines
{
    public class PatrolState : EnemyBaseState
    {
        public PatrolState(Player player) : base(player) 
        {
        }
    }
}
