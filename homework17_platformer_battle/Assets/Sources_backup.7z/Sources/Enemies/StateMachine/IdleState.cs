using Platformer.Game;

namespace Platformer.Enemies.StateMachines
{
    public class IdleState : EnemyBaseState
    {
        public IdleState(Player player) : base(player)
        {
        }
    }
}