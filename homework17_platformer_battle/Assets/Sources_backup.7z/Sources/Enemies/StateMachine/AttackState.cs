using Platformer.Game;

namespace Platformer.Enemies.StateMachines
{
    public class AttackState : EnemyBaseState
    {
        public AttackState(Player player) : base(player)
        {
        }
    }
}

