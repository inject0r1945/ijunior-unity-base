using Platformer.Game;

namespace Platformer.Enemies.StateMachines
{
    public class ChaseState : EnemyBaseState
    {
        public ChaseState(Player player) : base(player)
        {
        }
    }
}
