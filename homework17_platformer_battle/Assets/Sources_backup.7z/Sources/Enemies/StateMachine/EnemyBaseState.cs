using FiniteStateMachine.States;
using Platformer.Game;

namespace Platformer.Enemies.StateMachines
{
    public class EnemyBaseState : BaseState
    {
        private Player _player;

        public EnemyBaseState(Player player)
        {
            _player = player;
        }

        protected Player Player => _player;
    }
}
