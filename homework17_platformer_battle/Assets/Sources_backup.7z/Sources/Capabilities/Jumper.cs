using Platformer.Control;
using Platformer.Core;
using Sirenix.OdinInspector;
using System;
using UnityEngine;

namespace Platformer.Capabilities
{
    [RequireComponent(typeof(Rigidbody2D))]
    [RequireComponent(typeof(CollisionsDataRetriever))]
    [RequireComponent(typeof(ControlSettings))]
    public class Jumper : MonoBehaviour
    {
        [SerializeField, MinValue(0), Required] private float _jumpHeight = 3f;
        [SerializeField, MinValue(0), Required] private float _upwardGravityScale = 3f;
        [SerializeField, MinValue(0), Required] private float _downwardGravityScale = 1.7f;
        [SerializeField, MinValue(0), Required] private int _maxAirJumps = 1;
        [SerializeField, Range(0f, 0.3f)] private float _coyoteTime = 0.2f;
        [SerializeField, Range(0f, 0.3f)] private float _jumpBufferTime = 0.2f;

        private const float ZeroSpeedThreshold = 0.02f;
        private const float DefaultGravityScale = 1f;
        private Rigidbody2D _rigidbody;
        private CollisionsDataRetriever _collisionsDataRetriever;
        private InputController _inputController;
        private bool _onGround;
        private Vector2 _velocityCache;
        private int _jumpPhase;
        private bool _isDesiredJump;
        private bool _isProcessJumping;
        private float _coyoteCounter;
        private float _jumpBufferCounter;

        public event Action Jumped;

        public bool IsJumped => _jumpPhase > 0;

        private void Awake()
        {
            _rigidbody = GetComponent<Rigidbody2D>();
            _collisionsDataRetriever = GetComponent<CollisionsDataRetriever>();
            _inputController = GetComponent<ControlSettings>().InputController;
        }

        private void Start()
        {
            _jumpPhase = 0;
        }

        private void Update()
        {
            _isDesiredJump |= _inputController.RetrieveJumpInput();
            _onGround = _collisionsDataRetriever.OnGround;
        }

        private void FixedUpdate()
        {
            StartJumpBehaviour();
        }

        private void StartJumpBehaviour()
        {
            UpdateCelocityCache();

            if (IsInAirOrFalling() == false)
            {
                ResetJump();
            }
            else
            {
                UpdateCoyoteTimer();
            }

            HandleJumpInput();
            HandleJumpHoldInput();
        }

        private void UpdateCelocityCache()
        {
            _velocityCache = _rigidbody.velocity;
        }

        private bool IsInAirOrFalling()
        {
            return !_onGround || Mathf.Abs(_rigidbody.velocity.y) > ZeroSpeedThreshold;
        }

        private void ResetJump()
        {
            _jumpPhase = 0;
            _coyoteCounter = _coyoteTime;
            _isProcessJumping = false;
        }

        private void UpdateCoyoteTimer()
        {
            _coyoteCounter -= Time.deltaTime;
        }

        private void HandleJumpInput()
        {
            if (_isDesiredJump)
            {
                _isDesiredJump = false;
                _jumpBufferCounter = _jumpBufferTime;
            }
            else
            {
                _jumpBufferCounter = Mathf.Max(0, _jumpBufferCounter - Time.deltaTime);
            }

            if (_jumpBufferCounter > 0)
            {
                MakeJump();
            }
        }

        private void MakeJump()
        {
            if (_coyoteCounter > 0f || (_jumpPhase < _maxAirJumps && _isProcessJumping))
            {
                if (_isProcessJumping)
                    _jumpPhase++;

                AddJumpForce(ref _velocityCache);
            }
        }

        private void AddJumpForce(ref Vector2 velocity)
        {
            _jumpBufferCounter = 0f;
            _coyoteCounter = 0f;
            float jumpSpeedCoefficient = -2f;
            float jumpSpeed = Mathf.Sqrt(jumpSpeedCoefficient * Physics2D.gravity.y * _jumpHeight);
            _isProcessJumping = true;

            velocity.y = jumpSpeed;

            Jumped?.Invoke();
        }

        private void HandleJumpHoldInput()
        {
            bool isJumpHold = _inputController.RetrieveJumpHoldInput();

            if (isJumpHold && _rigidbody.velocity.y > ZeroSpeedThreshold)
                _rigidbody.gravityScale = _upwardGravityScale;

            else if (!isJumpHold || _rigidbody.velocity.y < -ZeroSpeedThreshold)
                _rigidbody.gravityScale = _downwardGravityScale;

            else
                _rigidbody.gravityScale = DefaultGravityScale;

            _rigidbody.velocity = _velocityCache;
        }
    }
}