using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Platformer.Capabilities
{
    public class Damager : MonoBehaviour
    {
    }
}
