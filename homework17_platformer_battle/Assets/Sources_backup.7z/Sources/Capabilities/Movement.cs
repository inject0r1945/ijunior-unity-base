using Platformer.Control;
using Platformer.Core;
using Sirenix.OdinInspector;
using UnityEngine;

namespace Platformer.Capabilities
{
    [RequireComponent(typeof(CollisionsDataRetriever))]
    [RequireComponent(typeof(Rigidbody2D))]
    [RequireComponent(typeof(ControlSettings))]
    public class Movement : MonoBehaviour
    {
        [SerializeField, MinValue(0), Required] private float _maxSpeed = 7f;
        [SerializeField, MinValue(0), Required] private float _maxAcceleration = 40f;
        [SerializeField, MinValue(0), Required] private float _maxAirAcceleration = 20f;

        private CollisionsDataRetriever _collisionsDataRetriever;
        private ControlSettings _controller;
        private Rigidbody2D _rigidbody;
        private Vector2 _velocity;
        private float _directionX;
        private float _desiredVelocityX;
        private float _maxSpeedChange;
        private float _acceleration;

        private void Awake()
        {
            _collisionsDataRetriever = GetComponent<CollisionsDataRetriever>();
            _rigidbody = GetComponent<Rigidbody2D>();
            _controller = GetComponent<ControlSettings>();
        }

        private void Update()
        {
            HandlePlayerInput();
        }

        private void FixedUpdate()
        {
            StartMoveBehaviour();
        }

        private void HandlePlayerInput()
        {
            _directionX = _controller.InputController.RetrieveMovementInput();
            _desiredVelocityX = _directionX * Mathf.Max(_maxSpeed - _collisionsDataRetriever.Friction, 0f);
        }

        private void StartMoveBehaviour()
        {
            _velocity = _rigidbody.velocity;
            _acceleration = _collisionsDataRetriever.OnGround ? _maxAcceleration : _maxAirAcceleration;
            _maxSpeedChange = _acceleration * Time.deltaTime;
            _velocity.x = Mathf.MoveTowards(_velocity.x, _desiredVelocityX, _maxSpeedChange);
            _rigidbody.velocity = _velocity;
        }
    }
}
