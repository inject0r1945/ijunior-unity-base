 using UnityEngine;

namespace Platformer.Player.StateMachine
{
    public class IdleState : BasePlayerState
    {
        private readonly int _idleStateIndex = 1;

        public IdleState(Animator animator) : base(animator)
        {
        }

        public override void OnEnter()
        {
            SetAnimatorState(_idleStateIndex);
        }
    }
}