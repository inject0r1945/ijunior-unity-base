using FiniteStateMachine.States;
using UnityEngine;

namespace Platformer
{
    public class BasePlayerState : BaseState
    {
        private readonly string _animatorStateParemeter = "State";
        private readonly int _animatorStateParemeterHash;
        private Animator _animator;

        public BasePlayerState(Animator animator)
        {
            _animator = animator;
            _animatorStateParemeterHash = Animator.StringToHash(_animatorStateParemeter);
        }

        protected void SetAnimatorState(int stateIndex)
        {
            _animator.SetInteger(_animatorStateParemeterHash, stateIndex);
        }
    }
}
