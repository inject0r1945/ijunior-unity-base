using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Platformer.Player.StateMachine
{
    public class RunState : BasePlayerState
    {
        private readonly int _runStateIndex = 0;

        public RunState(Animator animator) : base(animator)
        {
        }

        public override void OnEnter()
        {
            SetAnimatorState(_runStateIndex);
        }
    }
}